import random


class MonopolyGame:
    def __init__(self):
        self.board = [
            "Go", "Mediterranean Avenue", "Community Chest", "Baltic Avenue",
            "Income Tax", "Reading Railroad", "Oriental Avenue", "Chance",
            "Vermont Avenue", "Connecticut Avenue", "Jail", "St. Charles Place",
            "Electric Company", "States Avenue", "Virginia Avenue",
            "Pennsylvania Railroad", "St. James Place", "Community Chest",
            "Tennessee Avenue", "New York Avenue", "Free Parking", "Kentucky Avenue",
            "Chance", "Indiana Avenue", "Illinois Avenue", "B&O Railroad",
            "Atlantic Avenue", "Ventnor Avenue", "Water Works", "Marvin Gardens",
            "Go to Jail", "Pacific Avenue", "North Carolina Avenue", "Community Chest",
            "Pennsylvania Avenue", "Short Line", "Chance", "Park Place", "Luxury Tax",
            "Boardwalk"
        ]
        self.players = [{'name': 'Player', 'position': 0, 'money': 1500, 'properties': []},
                        {'name': 'CPU', 'position': 0, 'money': 1500, 'properties': []}]

        self.chance_cards = [
            "Advance to Go. Collect $200.",
            "You have won a crossword competition. Collect $100.",
            "Bank error in your favor. Collect $75.",
            "Pay poor tax of $15.",
            "Go directly to Jail. Do not pass Go, do not collect $200.",
            "Get out of Jail free. This card may be kept until needed.",
            "You inherit $100.",
            "Doctor's fees. Pay $50.",
            "It's your birthday. Collect $10 from each player.",
            "You have been elected chairman of the board. Pay each player $50."
        ]
        self.community_chest_cards = [
            "Advance to Go. Collect $200.",
            "You have won a crossword competition. Collect $100.",
            "Bank error in your favor. Collect $75.",
            "Pay poor tax of $15.",
            "Go directly to Jail. Do not pass Go, do not collect $200.",
            "Get out of Jail free. This card may be kept until needed.",
            "You inherit $100.",
            "Doctor's fees. Pay $50.",
            "It's your birthday. Collect $10 from each player.",
            "You have been elected chairman of the board. Pay each player $50."
        ]

    def display_status(self, player):
        print(
            f"\n{player['name']} - Position: {player['position']}, Money: {player['money']}, Properties: {', '.join(player['properties'])}")

    def roll_dice(self):
        return random.randint(1, 6) + random.randint(1, 6)

    def move_player(self, player, steps):
        player['position'] = (player['position'] + steps) % len(self.board)

    def buy_property(self, player, property_name):
        print(f"{player['name']} landed on {property_name}.")
        owned_by = self.property_owned_by(property_name)

        if owned_by:
            print(f"This property is already owned by {owned_by['name']}. Paying $50 in rent.")
            self.pay_rent(player, owned_by, 50)
        else:
            decision = input(f"Do you want to buy {property_name} for $200? (y/n): ")
            if decision.lower() == 'y':
                if player['money'] >= 200:
                    player['money'] -= 200
                    player['properties'].append(property_name)
                    print(f"{player['name']} bought {property_name} for $200.")
                else:
                    print(f"{player['name']} doesn't have enough money to buy {property_name}.")
            else:
                print(f"{player['name']} chose not to buy {property_name}.")

    def buy_property_cpu(self, player, property_name):
        print(f"{player['name']} (CPU) landed on {property_name}.")
        owned_by = self.property_owned_by(property_name)

        if owned_by:
            print(f"This property is already owned by {owned_by['name']}. Paying $50 in rent.")
            self.pay_rent(player, owned_by, 50)
        else:
            if player['money'] >= 200:
                player['money'] -= 200
                player['properties'].append(property_name)
                print(f"{player['name']} (CPU) bought {property_name} for $200.")
            else:
                print(f"{player['name']} (CPU) doesn't have enough money to buy {property_name}.")

    def roll_dice_cpu(self, player):
        dice_roll = self.roll_dice()
        print(f"{player['name']} (CPU) automatically rolled a {dice_roll}.")
        self.move_player(player, dice_roll)

    def pay_rent(self, payer, owner, rent_amount):
        print(f"{payer['name']} pays {owner['name']} $50 in rent.")
        payer['money'] -= rent_amount
        owner['money'] += rent_amount

    def property_owned_by(self, property_name):
        for player in self.players:
            if player['name'] != 'CPU' and property_name in player['properties']:
                return player
        return None

    def draw_chance_card(self, player):
        card = random.choice(self.chance_cards)
        print(f"{player['name']} drew a Chance card: {card}")

        if "Advance to Go" in card:
            player['position'] = self.board.index("Go")
            player['money'] += 200
            print(f"{player['name']} advances to Go and collects $200.")
        elif "You have won a crossword competition" in card:
            player['money'] += 100
            print(f"{player['name']} has won a crossword competition and collects $100.")
        elif "Bank error in your favor" in card:
            player['money'] += 75
            print(f"{player['name']} benefits from a bank error and collects $75.")
        elif "Pay poor tax" in card:
            player['money'] -= 15
            print(f"{player['name']} pays a poor tax of $15.")
        elif "Go directly to Jail" in card:
            player['position'] = self.board.index("Jail")
            print(f"{player['name']} goes directly to Jail.")
        elif "Get out of Jail free" in card:
            print(f"{player['name']} gets a 'Get out of Jail free' card.")
            # You can implement functionality to use this card when needed.
        elif "You inherit" in card:
            player['money'] += 100
            print(f"{player['name']} inherits $100.")
        elif "Doctor's fees" in card:
            player['money'] -= 50
            print(f"{player['name']} pays doctor's fees of $50.")
        elif "It's your birthday" in card:
            for other_player in self.players:
                if other_player['name'] != player['name']:
                    other_player['money'] -= 10
                    player['money'] += 10
            print(f"{player['name']} collects $10 from each player as a birthday gift.")
        elif "You have been elected chairman of the board" in card:
            for other_player in self.players:
                if other_player['name'] != player['name']:
                    other_player['money'] -= 50
                    player['money'] += 50
            print(f"{player['name']} has been elected chairman of the board and collects $50 from each player.")

    def draw_community_chest_card(self, player):
        card = random.choice(self.community_chest_cards)
        print(f"{player['name']} drew a Community Chest card: {card}")

        if "Advance to Go" in card:
            player['position'] = self.board.index("Go")
            player['money'] += 200
            print(f"{player['name']} advances to Go and collects $200.")
        elif "Bank error in your favor" in card:
            player['money'] += 200
            print(f"{player['name']} benefits from a bank error and collects $200.")
        elif "Doctor's fees" in card:
            player['money'] -= 50
            print(f"{player['name']} pays doctor's fees of $50.")
        elif "It's your birthday" in card:
            for other_player in self.players:
                if other_player['name'] != player['name']:
                    other_player['money'] -= 10
                    player['money'] += 10
            print(f"{player['name']} collects $10 from each player as a birthday gift.")
        # Add more Community Chest card actions as needed

    def play_turn(self, player):
        input(f"\n{player['name']}, press Enter to roll the dice.")
        dice_roll = self.roll_dice()
        print(f"{player['name']} rolled a {dice_roll}.")

        if player['position'] == self.board.index("Go to Jail"):
            print(f"{player['name']} goes directly to Jail and skips a turn.")
            player['position'] = self.board.index("Jail")
            return

        self.move_player(player, dice_roll)
        current_tile = self.board[player['position']]
        print(f"{player['name']} landed on {current_tile}.")

        if current_tile == 'Go':
            player['money'] += 200
            print(f"{player['name']} passed Go and collected $200.")
        elif current_tile == 'Chance':
            if self.draw_chance_card(player):
                return  # Skip the rest of the turn if the player goes to Jail
        elif current_tile == 'Community Chest':
            self.draw_community_chest_card(player)
        elif current_tile == 'Income Tax':
            self.pay_income_tax(player)
        elif current_tile not in ['Jail', 'Free Parking']:
            if player['name'] == 'CPU':
                self.play_turn_cpu(player)
            else:
                self.buy_property(player, current_tile)

    def pay_income_tax(self, player):
        decision = input(f"{player['name']}, do you want to pay 10% of your money for Income Tax? (y/n): ")
        if decision.lower() == 'y':
            tax_amount = int(player['money'] * 0.1)
            player['money'] -= tax_amount
            print(f"{player['name']} paid {tax_amount} for Income Tax.")
        else:
            print(f"{player['name']} chose not to pay Income Tax. They got audited for $500")
            player['money']-=500
    def play_turn_cpu(self, player):
        print(f"\n{player['name']} (CPU) is taking their turn...")
        self.roll_dice_cpu(player)
        current_tile = self.board[player['position']]
        print(f"{player['name']} (CPU) landed on {current_tile}.")
        if current_tile == 'Chance':
            self.draw_chance_card(player)
        elif current_tile not in ['Jail', 'Free Parking', 'Community Chest']:
            self.buy_property_cpu(player, current_tile)

    def play(self):
        print("Welcome to Text-Based Monopoly!")
        while all(player['money'] > 0 for player in self.players):
            for player in self.players:
                self.display_status(player)
                self.play_turn(player)


if __name__ == "__main__":
    game = MonopolyGame()
    game.play()

